const mySlider = new Slider({
  containerId: "slider-container",
  slideClass: "slide",
  title: "Sport Car Slider",
  prevArrowId: "prevArrow",
  nextArrowId: "nextArrow",
  nav: "false",
  autoplay: "true",
});

const mySlider2 = new Slider({
  containerId: "slider-container2",
  slideClass: "slide",
  title: "Sport Car Slider",
  prevArrowId: "prevArrow",
  nextArrowId: "nextArrow",
  nav: "true",
  autoplay: "false",
});
